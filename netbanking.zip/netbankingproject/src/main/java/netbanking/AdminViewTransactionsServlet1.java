package netbanking;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

public class AdminViewTransactionsServlet1 extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/netbankingdb?useSSL=false&allowPublicKeyRetrieval=true",
                "root", "MySQL@1234"); // change as per your setup

            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("SELECT * FROM transactions ORDER BY date DESC");

            out.println("<html><head><title>All Transactions</title>");
            out.println("<style>");
            out.println("body { font-family: Arial, sans-serif; background: #e0f7e0; margin:0; padding:0; display:flex; justify-content:center; align-items:center; height:100vh; }");
            out.println(".container { background-color: #d4edda; padding: 30px; border-radius: 15px; box-shadow: 0 10px 20px rgba(0,0,0,0.15); width: 800px; max-width: 90%; }");
            out.println("h2 { text-align: center; color: #155724; }");
            out.println("table { width: 100%; border-collapse: collapse; margin-top: 20px; }");
            out.println("th, td { border: 1px solid #28a745; padding: 10px; text-align: center; }");
            out.println("th { background-color: #28a745; color: white; }");
            out.println("a { display: inline-block; margin-top: 20px; padding: 10px 15px; background-color: #28a745; color: white; text-decoration: none; border-radius: 8px; transition: 0.3s; }");
            out.println("a:hover { background-color: #218838; }");
            out.println("</style>");
            out.println("</head><body>");
            
            out.println("<div class='container'>");
            out.println("<h2>All Transactions</h2>");
            out.println("<table>");
            out.println("<tr><th>ID</th><th>From Account</th><th>To Account</th><th>Amount</th><th>Date</th></tr>");

            while (rs.next()) {
                out.println("<tr>");
                out.println("<td>" + rs.getInt("id") + "</td>");
                out.println("<td>" + rs.getString("from_account") + "</td>");
                out.println("<td>" + rs.getString("to_account") + "</td>");
                out.println("<td>" + rs.getDouble("amount") + "</td>");
                out.println("<td>" + rs.getTimestamp("date") + "</td>");
                out.println("</tr>");
            }

            out.println("</table>");
            out.println("<div style='text-align:center;'><a href='admindashboard.jsp'>Back to Admin Dashboard</a></div>");
            out.println("</div>"); // container
            out.println("</body></html>");

            con.close();
        } catch (Exception e) {
            e.printStackTrace(out);
        }
    }
}
