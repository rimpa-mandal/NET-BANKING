package netbanking;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

public class CancelFDServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        String fdIdStr = request.getParameter("fd_id");

        if(fdIdStr == null || fdIdStr.isEmpty()) {
            out.println("<p style='color:red;'>Invalid Fixed Deposit ID!</p>");
            out.println("<a href='ViewFDServlet'>Back to FD List</a>");
            return;
        }

        try {
            int fdId = Integer.parseInt(fdIdStr);

            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/netbankingdb?useSSL=false&allowPublicKeyRetrieval=true",
                "root", "MySQL@1234");

            // Option 1: Delete FD from database
            PreparedStatement ps = con.prepareStatement("DELETE FROM fixed_deposits WHERE id=?");
            ps.setInt(1, fdId);
            int rows = ps.executeUpdate();

            if(rows > 0) {
                out.println("<!DOCTYPE html>");
                out.println("<html><head><title>FD Cancelled</title>");
                out.println("<style>");
                out.println("body{font-family:Arial,sans-serif;background:linear-gradient(to right,#74ebd5,#ACB6E5);text-align:center;padding:50px;}");
                out.println("a{display:inline-block;margin-top:20px;text-decoration:none;color:#fff;background:#333;padding:10px 15px;border-radius:5px;}");
                out.println("a:hover{background:#555;}");
                out.println("</style></head><body>");
                out.println("<h2>Fixed Deposit Cancelled Successfully!</h2>");
                out.println("<a href='ViewFDServlet'>Back to FD List</a>");
                out.println("</body></html>");
            } else {
                out.println("<p style='color:red;'>FD not found or already cancelled!</p>");
                out.println("<a href='ViewFDServlet'>Back to FD List</a>");
            }

            con.close();
        } catch(Exception e) {
            out.println("<p style='color:red;'>Error: " + e.getMessage() + "</p>");
            out.println("<a href='ViewFDServlet'>Back to FD List</a>");
        }
    }
}
