package netbanking;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

public class LoginServlet1 extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html");

        String accNo = request.getParameter("account_number");
        String password = request.getParameter("password");

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/netbankingdb?useSSL=false&allowPublicKeyRetrieval=true",
                "root", "MySQL@1234"); // <-- your MySQL password

            PreparedStatement ps = con.prepareStatement(
                "SELECT * FROM users WHERE account_number=? AND password=?");
            ps.setString(1, accNo);
            ps.setString(2, password);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                // ✅ Create session and store account number
                HttpSession session = request.getSession();
                session.setAttribute("account_number", accNo);

                // ✅ Redirect to dashboard.jsp
                response.sendRedirect("dashboard.jsp");
            } else {
                // Invalid login
                PrintWriter out = response.getWriter();
                out.println("<h2>Invalid Account Number or Password</h2>");
                out.println("<a href='login.jsp'>Try Again</a>");
            }

            con.close();
        } catch (Exception e) {
            e.printStackTrace();
            PrintWriter out = response.getWriter();
            out.println("<h2>Error: " + e.getMessage() + "</h2>");
        }
    }
}
