package netbanking;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

public class RecurringDepositServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        HttpSession session = request.getSession(false);
        if(session == null || session.getAttribute("account_number") == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        String accNo = (String) session.getAttribute("account_number");
        double monthlyAmount = Double.parseDouble(request.getParameter("monthly_amount"));
        double rate = Double.parseDouble(request.getParameter("interest_rate"));
        String startDate = request.getParameter("start_date");
        int duration = Integer.parseInt(request.getParameter("duration_months"));

        out.println("<!DOCTYPE html>");
        out.println("<html>");
        out.println("<head>");
        out.println("<title>Recurring Deposit Status</title>");
        out.println("<style>");
        out.println("body {margin:0; padding:0; font-family: Arial, sans-serif; height:100vh; width:100vw;");
        out.println("background: linear-gradient(135deg, #74ebd5, #ACB6E5); display:flex; justify-content:center; align-items:center;}");
        out.println(".container {background: rgba(255,255,255,0.95); border-radius:20px; box-shadow:0 15px 30px rgba(0,0,0,0.2);");
        out.println("padding:40px 50px; text-align:center; width:500px;}");
        out.println("h2 {color:#333; margin-bottom:25px;}");
        out.println("a {display:inline-block; margin-top:20px; padding:10px 20px; text-decoration:none; color:#fff;");
        out.println("background:#74ebd5; border-radius:10px; font-weight:bold; transition:0.3s;}");
        out.println("a:hover {background:#67d3c0; transform:scale(1.05);}");
        out.println("</style>");
        out.println("</head>");
        out.println("<body>");
        out.println("<div class='container'>");

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/netbankingdb?useSSL=false&allowPublicKeyRetrieval=true",
                "root", "MySQL@1234");

            PreparedStatement ps = con.prepareStatement(
                "INSERT INTO recurring_deposits (account_number, monthly_amount, interest_rate, start_date, duration_months) VALUES (?, ?, ?, ?, ?)");
            ps.setString(1, accNo);
            ps.setDouble(2, monthlyAmount);
            ps.setDouble(3, rate);
            ps.setString(4, startDate);
            ps.setInt(5, duration);

            ps.executeUpdate();
            con.close();

            out.println("<h2>Recurring Deposit Created Successfully!</h2>");
            out.println("<a href='dashboard.jsp'>⬅ Back to Dashboard</a>");

        } catch (Exception e) {
            out.println("<h2 style='color:red;'>Error: " + e.getMessage() + "</h2>");
            out.println("<a href='dashboard.jsp'>⬅ Back to Dashboard</a>");
        }

        out.println("</div>");
        out.println("</body>");
        out.println("</html>");
    }
}
