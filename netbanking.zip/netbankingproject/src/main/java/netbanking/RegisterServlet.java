package netbanking;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

public class RegisterServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        // Fetch form parameters
        String username = request.getParameter("name");
        String email = request.getParameter("email");
        String phone = request.getParameter("phone");
        String password = request.getParameter("password");

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/netbankingdb?useSSL=false&allowPublicKeyRetrieval=true",
                "root", "MySQL@1234");

            String accountNumber = "AC" + System.currentTimeMillis();

            PreparedStatement ps = con.prepareStatement(
                "INSERT INTO users (account_number, password, username, email, phone, balance) VALUES (?,?,?,?,?,?)"
            );
            ps.setString(1, accountNumber);
            ps.setString(2, password);
            ps.setString(3, username);
            ps.setString(4, email);
            ps.setString(5, phone);
            ps.setDouble(6, 1000.00);

            int result = ps.executeUpdate();

            // HTML Output with internal CSS
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Registration Result</title>");
            out.println("<style>");
            out.println("body {");
            out.println("  margin: 0;");
            out.println("  height: 100vh;");
            out.println("  display: flex;");
            out.println("  justify-content: center;");
            out.println("  align-items: center;");
            out.println("  background: linear-gradient(135deg, #667eea, #764ba2);");
            out.println("  font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;");
            out.println("}");
            out.println(".container {");
            out.println("  width: 400px;");
            out.println("  max-width: 90%;");
            out.println("  background-color: #fff;");
            out.println("  padding: 30px;");
            out.println("  border-radius: 15px;");
            out.println("  box-shadow: 0 10px 25px rgba(0,0,0,0.15);");
            out.println("  text-align: center;");
            out.println("}");
            out.println(".success { color: #28a745; font-size: 24px; font-weight: bold; margin-bottom: 15px; }");
            out.println(".error { color: #dc3545; font-size: 24px; font-weight: bold; margin-bottom: 15px; }");
            out.println("p { font-size: 18px; margin: 15px 0; }");
            out.println("a { display: inline-block; margin-top: 20px; padding: 12px 25px; background-color: #667eea; color: #fff; text-decoration: none; border-radius: 8px; transition: 0.3s; }");
            out.println("a:hover { background-color: #5a67d8; }");
            out.println("</style>");
            out.println("</head>");
            out.println("<body>");
            out.println("<div class='container'>");

            if (result > 0) {
                out.println("<h2 class='success'> Registration Successful!</h2>");
                out.println("<p>Your Account Number: <b>" + accountNumber + "</b></p>");
                out.println("<a href='login.jsp'>Login Here</a>");
            } else {
                out.println("<h2 class='error'> Registration Failed!</h2>");
                out.println("<a href='register.jsp'>Try Again</a>");
            }

            out.println("</div>");
            out.println("</body>");
            out.println("</html>");

            con.close();

        } catch (Exception e) {
            e.printStackTrace(out);
        }
    }
}
