<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <title>Register - NetBanking</title>
    <style>
        /* Body styling */
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #e0f7fa; /* subtle light background */
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        /* Fixed size container */
        .form-container {
            background-color: #ffffff; /* container background */
            padding: 40px 30px;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            width: 400px;  /* fixed width */
            max-width: 95%; /* responsive on very small screens */
            text-align: center;
            box-sizing: border-box;
            overflow: hidden; /* prevents inputs from going outside */
        }

        /* Heading */
        .form-container h2 {
            color: #333333;
            margin-bottom: 30px;
            font-weight: 700;
            font-size: 28px;
        }

        /* Input fields with equal spacing */
        .form-container input[type="text"],
        .form-container input[type="password"],
        .form-container input[type="email"],
        .form-container input[type="tel"] {
            width: 100%;
            padding: 15px;
            margin-bottom: 20px; /* equal spacing */
            border: 2px solid #ddd;
            border-radius: 8px;
            font-size: 16px;
            box-sizing: border-box; /* ensures padding inside width */
            transition: all 0.3s ease;
        }

        .form-container input[type="text"]:focus,
        .form-container input[type="password"]:focus,
        .form-container input[type="email"]:focus,
        .form-container input[type="tel"]:focus {
            border-color: #26c6da;
            box-shadow: 0 0 8px rgba(38, 198, 218, 0.3);
            outline: none;
        }

        /* Submit button */
        .form-container input[type="submit"] {
            width: 100%;
            padding: 16px;
            border: none;
            border-radius: 8px;
            background-color: #26c6da;
            color: white;
            font-size: 18px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .form-container input[type="submit"]:hover {
            background-color: #00acc1;
            transform: translateY(-2px);
        }

        .form-container input[type="submit"]:active {
            transform: translateY(1px) scale(0.98);
        }

        /* Link styling */
        .form-container p {
            margin-top: 22px;
            color: #555555;
            font-size: 14px;
        }

        .form-container a {
            color: #26c6da;
            text-decoration: none;
            font-weight: 500;
            transition: color 0.3s ease;
        }

        .form-container a:hover {
            color: #00acc1;
            text-decoration: underline;
        }

        /* Small screens adjustments */
        @media (max-width: 420px) {
            .form-container {
                width: 95%; /* keeps inside screen */
                padding: 30px 20px;
            }

            .form-container h2 {
                font-size: 24px;
            }

            .form-container input[type="text"],
            .form-container input[type="password"],
            .form-container input[type="email"],
            .form-container input[type="tel"],
            .form-container input[type="submit"] {
                font-size: 14px;
                padding: 14px;
            }
        }

    </style>
</head>
<body>
    <div class="form-container">
        <h2>Register</h2>
        <form action="RegisterServlet" method="post">
            <input type="text" name="username" placeholder="Username" required />
            <input type="password" name="password" placeholder="Password" required />
            <input type="email" name="email" placeholder="Email" required />
            <input type="tel" name="phone" placeholder="Phone Number" required />
            <input type="submit" value="Register" />
        </form>
        <p>Already have an account? <a href="login.jsp">Login here</a></p>
    </div>
</body>
</html>
