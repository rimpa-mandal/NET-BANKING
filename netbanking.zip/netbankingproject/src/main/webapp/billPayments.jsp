<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="javax.servlet.http.*,javax.servlet.*" %>
<%
    String accountNumber = (String) session.getAttribute("account_number");
    if (accountNumber == null) {
        response.sendRedirect("login.jsp");
        return;
    }
%>
<!DOCTYPE html>
<html>
<head>
    <title>Pay Bill</title>
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            height: 100vh;
            background: linear-gradient(135deg, #6a11cb, #2575fc); /* Purple to blue gradient */
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .container {
            width: 400px;
            padding: 30px;
            background-color: #ffffff; /* White box */
            border-radius: 12px;
            box-shadow: 0 8px 20px rgba(0,0,0,0.3);
            text-align: center;
        }
        h2 {
            color: #333;
            margin-bottom: 25px;
        }
        label {
            display: block;
            margin-top: 15px;
            font-weight: bold;
            text-align: left;
        }
        input[type="text"], input[type="number"], select {
            width: 100%;
            padding: 10px;
            margin-top: 5px;
            border-radius: 6px;
            border: 1px solid #ccc;
            box-sizing: border-box;
        }
        input[type="submit"] {
            width: 100%;
            margin-top: 25px;
            padding: 12px;
            background-color: #2575fc;
            color: white;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s;
        }
        input[type="submit"]:hover {
            background-color: #6a11cb;
        }
        select option {
            padding: 10px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Bill Payment</h2>
        <form action="BillPaymentServlet" method="post">
            <label>From Account:</label>
            <input type="text" name="from_account" value="<%=accountNumber%>" readonly>

            <label>Bill Type:</label>
            <select name="bill_type">
                <option value="BILL_ELEC">Electricity</option>
                <option value="BILL_WATER">Water</option>
                <option value="BILL_GAS">Gas</option>
            </select>

            <label>Amount:</label>
            <input type="number" name="amount" step="0.01" required>

            <input type="submit" value="Pay Bill">
        </form>
    </div>
</body>
</html>
