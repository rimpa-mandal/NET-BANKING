<%@ page language="java" contentType="text/html; charset=UTF-8"%>
<%
    String accountNumber = (String) session.getAttribute("account_number");
    if(accountNumber == null){
        response.sendRedirect("login.jsp");
        return;
    }
%>
<!DOCTYPE html>
<html>
<head>
    <title>Transaction History</title>
    <style>
        /* Body styling with gradient background */
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            background: linear-gradient(135deg, #74ebd5, #ACB6E5);
        }

        /* Fixed container styling */
        .container {
            background: rgba(255, 255, 255, 0.95);
            padding: 40px 50px;
            border-radius: 20px;
            box-shadow: 0 15px 30px rgba(0,0,0,0.2);
            width: 800px;
            max-height: 80vh;
            overflow-y: auto;
            text-align: center;
        }

        .container h2 {
            margin-bottom: 25px;
            color: #333;
            font-size: 28px;
        }

        /* Table styling */
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
        }

        th, td {
            border: 1px solid #ccc;
            padding: 10px;
            text-align: center;
            font-size: 14px;
        }

        th {
            background-color: #74ebd5;
            color: #fff;
        }

        tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        /* Back link styling */
        .container p {
            margin-top: 20px;
        }

        .container a {
            display: inline-block;
            padding: 10px 20px;
            border-radius: 10px;
            text-decoration: none;
            background: #74ebd5;
            color: #fff;
            font-weight: bold;
            transition: background 0.3s, transform 0.3s;
        }

        .container a:hover {
            background: #67d3c0;
            transform: scale(1.05);
        }
    </style>
</head>
<body>
<div class="container">
    <h2>Your Transaction History</h2>
    <table>
        <tr>
            <th>ID</th>
            <th>From Account</th>
            <th>To Account</th>
            <th>Amount</th>
            <th>Date</th>
        </tr>
        <%
            java.sql.Connection con = null;
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                con = java.sql.DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/netbankingdb","root","MySQL@1234");
                java.sql.PreparedStatement ps = con.prepareStatement(
                    "SELECT * FROM transactions WHERE from_account=? OR to_account=? ORDER BY date DESC");
                ps.setString(1, accountNumber);
                ps.setString(2, accountNumber);
                java.sql.ResultSet rs = ps.executeQuery();
                while(rs.next()){
        %>
        <tr>
            <td><%= rs.getInt("id") %></td>
            <td><%= rs.getString("from_account") %></td>
            <td><%= rs.getString("to_account") %></td>
            <td><%= rs.getDouble("amount") %></td>
            <td><%= rs.getTimestamp("date") %></td>
        </tr>
        <%
                }
                con.close();
            } catch(Exception e) { e.printStackTrace(); }
        %>
    </table>
    <p><a href="dashboard.jsp">Back to Dashboard</a></p>
</div>
</body>
</html>
