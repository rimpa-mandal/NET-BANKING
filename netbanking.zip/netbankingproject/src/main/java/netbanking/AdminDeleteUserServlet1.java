package netbanking;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

public class AdminDeleteUserServlet1 extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String accountNumber = request.getParameter("account_number");
        response.setContentType("text/html;charset=UTF-8");

        try (PrintWriter out = response.getWriter()) {
            // JDBC
            Class.forName("com.mysql.cj.jdbc.Driver");
            try (Connection con = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/netbankingdb?useSSL=false&allowPublicKeyRetrieval=true",
                    "root", "MySQL@1234")) {   // update password

                PreparedStatement ps = con.prepareStatement(
                        "DELETE FROM users WHERE account_number=?");
                ps.setString(1, accountNumber);

                int rows = ps.executeUpdate();

                out.println("<!DOCTYPE html>");
                out.println("<html><head><title>Delete User</title>");
                out.println("<style>");
                out.println("body {font-family: Arial, sans-serif; background:#f4f4f4; text-align:center;}");
                out.println(".box {background:#fff; padding:20px; margin:100px auto; width:400px; border-radius:8px; box-shadow:0 4px 10px rgba(0,0,0,0.2);}");
                out.println("a {display:inline-block; margin-top:15px; text-decoration:none; color:#fff; background:#007bff; padding:8px 15px; border-radius:5px;}");
                out.println("a:hover {background:#0056b3;}");
                out.println("</style>");
                out.println("</head><body>");
                out.println("<div class='box'>");

                if (rows > 0) {
                    out.println("<h3>User with Account Number <b>" + accountNumber + "</b> deleted successfully ✅</h3>");
                } else {
                    out.println("<h3>❌ No user found with Account Number <b>" + accountNumber + "</b>.</h3>");
                }

                out.println("<a href='admindashboard.jsp'>Back to Admin Dashboard</a>");
                out.println("</div></body></html>");
            }
        } catch (Exception e) {
            throw new ServletException("Error deleting user", e);
        }
    }

    // Handle accidental GET requests gracefully
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.sendRedirect("adminDashboard.jsp");
    }
}
