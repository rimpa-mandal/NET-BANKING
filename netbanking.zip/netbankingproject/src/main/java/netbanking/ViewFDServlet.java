package netbanking;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

public class ViewFDServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        String accNo = (String) request.getSession().getAttribute("account_number");

        out.println("<!DOCTYPE html>");
        out.println("<html><head><title>My Fixed Deposits</title>");
        out.println("<style>");
        out.println("body{font-family:Arial,sans-serif;background:linear-gradient(to right,#74ebd5,#ACB6E5);margin:0;padding:0;}");
        out.println(".container{width:80%;margin:50px auto;background:#fff;padding:20px;border-radius:15px;box-shadow:0 4px 10px rgba(0,0,0,0.2);}");
        out.println("h2{text-align:center;color:#333;}");
        out.println("table{width:100%;border-collapse:collapse;margin-top:20px;}");
        out.println("table th,table td{border:1px solid #ddd;padding:12px;text-align:center;}");
        out.println("table th{background:#f2f2f2;}");
        out.println(".back-link{display:inline-block;margin-top:20px;text-decoration:none;color:#fff;background:#333;padding:10px 15px;border-radius:5px;transition:0.3s;}");
        out.println(".back-link:hover{background:#555;}");
        out.println(".cancel-btn{background:#e74c3c;color:white;border:none;padding:8px 12px;border-radius:5px;cursor:pointer;transition:0.3s;}");
        out.println(".cancel-btn:hover{background:#c0392b;}");
        out.println("</style></head><body>");
        out.println("<div class='container'><h2>My Fixed Deposits</h2>");

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/netbankingdb?useSSL=false&allowPublicKeyRetrieval=true",
                "root", "MySQL@1234");

            PreparedStatement ps = con.prepareStatement(
                "SELECT id, amount, interest_rate, start_date, maturity_date, status FROM fixed_deposits WHERE account_number=?");
            ps.setString(1, accNo);
            ResultSet rs = ps.executeQuery();

            out.println("<table>");
            out.println("<tr><th>Amount</th><th>Interest Rate (%)</th><th>Start Date</th><th>Maturity Date</th><th>Status</th><th>Action</th></tr>");
            boolean found = false;
            while(rs.next()) {
                found = true;
                int id = rs.getInt("id");
                out.println("<tr>");
                out.println("<td>" + rs.getDouble("amount") + "</td>");
                out.println("<td>" + rs.getDouble("interest_rate") + "</td>");
                out.println("<td>" + rs.getString("start_date") + "</td>");
                out.println("<td>" + rs.getString("maturity_date") + "</td>");
                out.println("<td>" + rs.getString("status") + "</td>");
                out.println("<td><form action='CancelFDServlet' method='post'>");
                out.println("<input type='hidden' name='fd_id' value='" + id + "'>");
                out.println("<input type='submit' class='cancel-btn' value='Cancel'>");
                out.println("</form></td>");
                out.println("</tr>");
            }
            if(!found){
                out.println("<tr><td colspan='6' style='text-align:center;'>No Fixed Deposits Found</td></tr>");
            }
            out.println("</table>");
            con.close();
        } catch(Exception e) {
            out.println("<p style='color:red;'>Error: " + e.getMessage() + "</p>");
        }

        out.println("<a href='dashboard.jsp' class='back-link'>⬅ Back to Dashboard</a>");
        out.println("</div></body></html>");
    }
}
