package netbanking;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class AdminViewUsersServlet1 extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        // Check if admin is logged in
        HttpSession session = request.getSession();
        String accountNumber = (String) session.getAttribute("account_number");
        if (accountNumber == null) {
            response.sendRedirect("adminLogin.jsp");
            return;
        }

        out.println("<!DOCTYPE html>");
        out.println("<html>");
        out.println("<head>");
        out.println("<meta charset='UTF-8'>");
        out.println("<title>View Users - Admin</title>");
        out.println("<style>");
        out.println("body {");
        out.println("  font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;");
        out.println("  background: linear-gradient(135deg, #e0f7e0, #c6f0c6);");
        out.println("  margin: 0; padding: 0;");
        out.println("  height: 100vh; display: flex; justify-content: center; align-items: center;");
        out.println("}");
        out.println(".container {");
        out.println("  background-color: #d4edda;"); // light green
        out.println("  padding: 30px 20px;");
        out.println("  width: 700px;");
        out.println("  border-radius: 15px;");
        out.println("  box-shadow: 0 10px 20px rgba(0,0,0,0.15);");
        out.println("  overflow-x: auto;");
        out.println("}");
        out.println("h1 { color: #155724; text-align: center; margin-bottom: 20px; }");
        out.println("table { width: 100%; border-collapse: collapse; margin-top: 10px; }");
        out.println("th, td { padding: 10px; text-align: center; border: 1px solid #28a745; }");
        out.println("th { background-color: #28a745; color: white; }");
        out.println("tr:nth-child(even) { background-color: #c6f0c6; }");
        out.println("</style>");
        out.println("</head>");
        out.println("<body>");
        out.println("<div class='container'>");
        out.println("<h1>All Users</h1>");
        out.println("<table>");
        out.println("<tr><th>ID</th><th>Account Number</th><th>Username</th><th>Email</th><th>Phone</th><th>Balance</th></tr>");

        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/netbankingdb", "root", "MySQL@1234");
            stmt = conn.createStatement();

            String sql = "SELECT id, account_number, username, email, phone, balance FROM users";
            rs = stmt.executeQuery(sql);

            while (rs.next()) {
                out.println("<tr>");
                out.println("<td>" + rs.getInt("id") + "</td>");
                out.println("<td>" + rs.getString("account_number") + "</td>");
                out.println("<td>" + rs.getString("username") + "</td>");
                out.println("<td>" + rs.getString("email") + "</td>");
                out.println("<td>" + rs.getString("phone") + "</td>");
                out.println("<td>" + rs.getDouble("balance") + "</td>");
                out.println("</tr>");
            }
        } catch (Exception e) {
            e.printStackTrace(out);
        } finally {
            try { if (rs != null) rs.close(); } catch (Exception e) {}
            try { if (stmt != null) stmt.close(); } catch (Exception e) {}
            try { if (conn != null) conn.close(); } catch (Exception e) {}
        }

        out.println("</table>");
        out.println("</div>");
        out.println("</body>");
        out.println("</html>");
    }
}
