<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Admin Adjust Balance</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #e0f7e0, #c6f0c6);
            margin: 0;
            padding: 0;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .container {
            background-color: #d4edda; /* light green */
            padding: 40px 30px;
            width: 400px;
            border-radius: 15px;
            box-shadow: 0 10px 20px rgba(0,0,0,0.15);
            text-align: center;
        }

        h2 {
            color: #155724;
            margin-bottom: 25px;
        }

        form {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }

        input[type="text"],
        input[type="number"],
        select {
            padding: 10px;
            border-radius: 8px;
            border: 1px solid #28a745;
            font-size: 16px;
        }

        input[type="submit"] {
            padding: 12px;
            border-radius: 8px;
            border: none;
            background-color: #28a745;
            color: white;
            font-size: 16px;
            cursor: pointer;
            transition: 0.3s;
        }

        input[type="submit"]:hover {
            background-color: #218838;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Adjust User Balance</h2>
        <form action="AdminAdjustBalanceServlet" method="post">
            <input type="text" name="account_number" placeholder="Account Number" required>

            <select name="action" required>
                <option value="" disabled selected>Select Action</option>
                <option value="credit">Credit</option>
                <option value="debit">Debit</option>
            </select>

            <input type="number" name="amount" step="0.01" placeholder="Amount" required>

            <input type="submit" value="Update Balance">
        </form>
    </div>
</body>
</html>
