<%@ page import="java.util.*" %>
<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%
    String accNo = (String) session.getAttribute("account_number");
    if(accNo == null) {
        response.sendRedirect("login.jsp");
        return;
    }
%>
<!DOCTYPE html>
<html>
<head>
    <title>My Recurring Deposits</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<div class="container">
    <h2>My Recurring Deposits</h2>
    <table border="1" width="100%" cellpadding="10">
        <tr>
            <th>Monthly Amount</th>
            <th>Interest Rate (%)</th>
            <th>Start Date</th>
            <th>Duration (Months)</th>
            <th>Status</th>
            <th>Action</th>
        </tr>
        <%
            List<String[]> rdList = (List<String[]>) request.getAttribute("rdList");
            if(rdList != null && !rdList.isEmpty()) {
                for(String[] rd : rdList) {
        %>
        <tr>
            <td><%= rd[0] %></td>
            <td><%= rd[1] %></td>
            <td><%= rd[2] %></td>
            <td><%= rd[3] %></td>
            <td><%= rd[4] %></td>
            <td>
                <form action="CancelRDServlet" method="post">
                    <input type="hidden" name="rd_id" value="<%= rd[5] %>"> <!-- rd[5] = id -->
                    <% if(!rd[4].equals("Cancelled")) { %>
                        <input type="submit" value="Cancel" class="cancel-btn">
                    <% } else { %>
                        <span>Cancelled</span>
                    <% } %>
                </form>
            </td>
        </tr>
        <%      }
            } else {
        %>
        <tr><td colspan="6" style="text-align:center;">No Recurring Deposits Found</td></tr>
        <% } %>
    </table>
    <br>
    <a href="dashboard.jsp" class="back-link">⬅ Back to Dashboard</a>
</div>
</body>
</html>
