<%@ page language="java" contentType="text/html; charset=UTF-8"%>
<%
    String accountNumber = (String) session.getAttribute("account_number");
    if(accountNumber == null){
        response.sendRedirect("login.jsp");
        return;
    }
%>
<!DOCTYPE html>
<html>
<head>
    <title>Fund Transfer</title>
    <style>
        /* Body styling with gradient background */
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            background: linear-gradient(135deg, #ff9a9e, #fad0c4);
        }

        /* Container styling */
        .container {
            background: rgba(255, 255, 255, 0.95);
            padding: 40px 50px;
            border-radius: 20px;
            box-shadow: 0 15px 30px rgba(0,0,0,0.2);
            width: 400px;
            text-align: center;
            transition: transform 0.3s ease;
        }

        .container:hover {
            transform: translateY(-5px);
        }

        /* Header */
        .container h2 {
            margin-bottom: 25px;
            color: #333;
            font-size: 28px;
        }

        /* Input fields */
        .container input[type="text"],
        .container input[type="number"] {
            width: 100%;
            padding: 12px 15px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 10px;
            font-size: 16px;
            outline: none;
            transition: all 0.3s ease;
        }

        .container input[type="text"]:focus,
        .container input[type="number"]:focus {
            border-color: #ff6a88;
            box-shadow: 0 0 5px rgba(255,106,136,0.5);
        }

        /* Submit button */
        .container input[type="submit"] {
            width: 100%;
            padding: 12px 15px;
            margin-top: 15px;
            border: none;
            border-radius: 10px;
            background: #ff6a88;
            color: #fff;
            font-size: 18px;
            cursor: pointer;
            transition: background 0.3s ease, transform 0.3s ease;
        }

        .container input[type="submit"]:hover {
            background: #ff4a66;
            transform: scale(1.05);
        }

        /* Back link */
        .container p {
            margin-top: 15px;
            font-size: 14px;
        }

        .container a {
            color: #ff6a88;
            text-decoration: none;
            font-weight: bold;
        }

        .container a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Fund Transfer</h2>
        <form action="TransferServlet" method="post">
            <input type="text" name="to_account" placeholder="Recipient Account Number" required />
            <input type="number" step="0.01" name="amount" placeholder="Amount" required />
            <input type="submit" value="Transfer" />
        </form>
        <p><a href="dashboard.jsp">Back to Dashboard</a></p>
    </div>
</body>
</html>
