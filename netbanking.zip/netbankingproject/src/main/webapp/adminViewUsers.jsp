<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <title>Admin - View Users</title>
</head>
<body>
    <h2>Click below to view all users:</h2>
    <form action="AdminViewUsersServlet1" method="get">
        <input type="submit" value="View Users">
    </form>
    <br>
    <a href="adminDashboard.jsp">Back to Admin Dashboard</a>
</body>
</html>
