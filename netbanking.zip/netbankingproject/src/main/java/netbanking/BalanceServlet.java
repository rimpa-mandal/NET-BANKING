package netbanking;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

public class BalanceServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("account_number") == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        String accNo = (String) session.getAttribute("account_number");

        out.println("<!DOCTYPE html>");
        out.println("<html><head><title>Account Balance</title>");
        out.println("<style>");
        out.println("body { display:flex; justify-content:center; align-items:center; height:100vh; font-family:Arial, sans-serif; margin:0; background: linear-gradient(135deg, #74ebd5, #ACB6E5); }");
        out.println(".container { background: rgba(255,255,255,0.95); padding: 40px 50px; border-radius: 20px; box-shadow: 0 15px 30px rgba(0,0,0,0.2); width: 400px; text-align:center; }");
        out.println(".container h2 { font-size:28px; color:#333; margin-bottom:20px; }");
        out.println(".balance { font-size: 24px; color: #4CAF50; margin: 20px 0; }");
        out.println(".btn { display:inline-block; padding: 10px 20px; border-radius:10px; text-decoration:none; background:#74ebd5; color:#fff; font-weight:bold; transition: background 0.3s, transform 0.3s; }");
        out.println(".btn:hover { background:#67d3c0; transform: scale(1.05); }");
        out.println(".error { color: red; font-size: 20px; margin: 20px 0; }");
        out.println("</style></head><body>");
        out.println("<div class='container'>");

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/netbankingdb?useSSL=false&allowPublicKeyRetrieval=true",
                "root", "MySQL@1234");

            PreparedStatement ps = con.prepareStatement(
                "SELECT balance FROM users WHERE account_number=?");
            ps.setString(1, accNo);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                double balance = rs.getDouble("balance");
                out.println("<h2>Account Balance</h2>");
                out.println("<div class='balance'>" + String.format("%.2f", balance) + "</div>");
                out.println("<a class='btn' href='dashboard.jsp'>Back to Dashboard</a>");
            } else {
                out.println("<div class='error'>Account not found</div>");
                out.println("<a class='btn' href='dashboard.jsp'>Back to Dashboard</a>");
            }

            con.close();
        } catch (Exception e) {
            out.println("<div class='error'>Error: " + e.getMessage() + "</div>");
            out.println("<a class='btn' href='dashboard.jsp'>Back to Dashboard</a>");
        }

        out.println("</div></body></html>");
    }
}
