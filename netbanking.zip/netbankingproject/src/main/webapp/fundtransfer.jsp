<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <title>Fund Transfer</title>
    <style>
        body { font-family: Arial; background: #f2f2f2; }
        .container {
            width: 400px; margin: 100px auto; padding: 20px;
            background: white; border-radius: 10px; box-shadow: 0 0 10px gray;
        }
        h2 { text-align: center; }
        input[type=text], input[type=number] {
            width: 100%; padding: 10px; margin: 8px 0; border-radius: 5px; border: 1px solid #ccc;
        }
        input[type=submit] {
            background: green; color: white; padding: 10px; width: 100%;
            border: none; border-radius: 5px; cursor: pointer;
        }
        input[type=submit]:hover { background: darkgreen; }
    </style>
</head>
<body>
    <div class="container">
        <h2>Fund Transfer</h2>
        <form action="TransferServlet" method="post">
            <label>Recipient Account Number:</label>
            <input type="text" name="to_account" required>

            <label>Amount:</label>
            <input type="number" name="amount" step="0.01" required>

            <input type="submit" value="Transfer">
        </form>
        <br>
        <a href="dashboard.jsp">Back to Dashboard</a>
    </div>
</body>
</html>
