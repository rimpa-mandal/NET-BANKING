<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <title>Admin - View Transactions</title>
</head>
<body>
    <h2>Click below to view all transactions:</h2>
    <form action="AdminViewTransactionsServlet1" method="get">
        <input type="submit" value="View Transactions">
    </form>
    <br>
    <a href="adminDashboard.jsp">Back to Admin Dashboard</a>
</body>
</html>
