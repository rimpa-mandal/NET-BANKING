<%@ page import="java.util.*" %>
<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%
    String accNo = (String) session.getAttribute("account_number");
    if(accNo == null) {
        response.sendRedirect("login.jsp");
        return;
    }
%>
<!DOCTYPE html>
<html>
<head>
    <title>My Fixed Deposits</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<div class="container">
    <h2>My Fixed Deposits</h2>
    <table border="1" width="100%" cellpadding="10">
        <tr>
            <th>Amount</th>
            <th>Interest Rate (%)</th>
            <th>Start Date</th>
            <th>Maturity Date</th>
            <th>Status</th>
            <th>Action</th>
        </tr>
        <%
            List<String[]> fdList = (List<String[]>) request.getAttribute("fdList");
            if(fdList != null && !fdList.isEmpty()) {
                for(String[] fd : fdList) {
        %>
        <tr>
            <td><%= fd[0] %></td>
            <td><%= fd[1] %></td>
            <td><%= fd[2] %></td>
            <td><%= fd[3] %></td>
            <td><%= fd[4] %></td>
            <td>
                <form action="CancelFDServlet" method="post">
                    <input type="hidden" name="fd_id" value="<%= fd[5] %>"> <!-- fd[5] = id -->
                    <% if(!fd[4].equals("Cancelled")) { %>
                        <input type="submit" value="Cancel" class="cancel-btn">
                    <% } else { %>
                        <span>Cancelled</span>
                    <% } %>
                </form>
            </td>
        </tr>
        <%      }
            } else {
        %>
        <tr><td colspan="6" style="text-align:center;">No Fixed Deposits Found</td></tr>
        <% } %>
    </table>
    <br>
    <a href="dashboard.jsp" class="back-link">⬅ Back to Dashboard</a>
</div>
</body>
</html>
