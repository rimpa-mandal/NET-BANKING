<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SecureNet Banking - Home</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* Global Styles */
        :root {
            --primary: #1a4f72;
            --secondary: #3a7dbd;
            --accent: #28a745;
            --admin: #dc3545;
            --light: #f8f9fa;
            --dark: #212529;
            --gradient-start: #1a4f72;
            --gradient-end: #2c7da0;
            --card-bg: rgba(255, 255, 255, 0.95);
            --shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
            background: linear-gradient(135deg, var(--gradient-start), var(--gradient-end));
            color: var(--dark);
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            padding: 20px;
            position: relative;
            overflow-x: hidden;
        }
        
        /* Background elements for visual interest */
        .bg-circle {
            position: absolute;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.1);
            z-index: -1;
        }
        
        .circle-1 {
            width: 300px;
            height: 300px;
            top: -100px;
            right: -100px;
        }
        
        .circle-2 {
            width: 200px;
            height: 200px;
            bottom: -50px;
            left: -50px;
        }
        
        /* Main Container */
        .container {
            width: 100%;
            max-width: 480px;
            background: var(--card-bg);
            border-radius: 20px;
            padding: 40px 35px;
            text-align: center;
            box-shadow: var(--shadow);
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            transform: translateY(0);
            transition: transform 0.4s ease, box-shadow 0.4s ease;
            position: relative;
            overflow: hidden;
        }
        
        .container:hover {
            transform: translateY(-7px);
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.15);
        }
        
        /* Decorative top bar */
        .container::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 6px;
            background: linear-gradient(90deg, var(--primary), var(--secondary));
        }
        
        /* Logo and Branding */
        .logo {
            margin-bottom: 25px;
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 12px;
        }
        
        .logo-icon {
            font-size: 32px;
            color: var(--primary);
            background: rgba(26, 79, 114, 0.1);
            width: 60px;
            height: 60px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .logo-text {
            font-size: 28px;
            font-weight: 700;
            color: var(--primary);
            letter-spacing: 0.5px;
        }
        
        /* Heading */
        .welcome-text {
            color: var(--primary);
            margin-bottom: 10px;
            font-size: 22px;
            font-weight: 600;
        }
        
        .subtitle {
            color: #666;
            margin-bottom: 35px;
            font-size: 15px;
            font-weight: 400;
        }
        
        /* Buttons */
        .btn-container {
            display: flex;
            flex-direction: column;
            gap: 18px;
            margin-top: 30px;
        }
        
        .btn {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 12px;
            padding: 16px 24px;
            border-radius: 12px;
            text-decoration: none;
            font-weight: 600;
            font-size: 16px;
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
        }
        
        .btn span {
            position: relative;
            z-index: 2;
        }
        
        .btn i {
            font-size: 18px;
            position: relative;
            z-index: 2;
        }
        
        .btn::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.3), transparent);
            transition: all 0.6s ease;
        }
        
        .btn:hover::before {
            left: 100%;
        }
        
        .btn-primary {
            background: var(--primary);
            color: white;
        }
        
        .btn-primary:hover {
            background: #153a57;
            transform: translateY(-2px);
            box-shadow: 0 6px 15px rgba(26, 79, 114, 0.25);
        }
        
        .btn-secondary {
            background: var(--secondary);
            color: white;
        }
        
        .btn-secondary:hover {
            background: #2c6da6;
            transform: translateY(-2px);
            box-shadow: 0 6px 15px rgba(58, 125, 189, 0.25);
        }
        
        .btn-admin {
            background: var(--admin);
            color: white;
        }
        
        .btn-admin:hover {
            background: #bd2130;
            transform: translateY(-2px);
            box-shadow: 0 6px 15px rgba(220, 53, 69, 0.25);
        }
        
        /* Security Badge */
        .security-badge {
            margin-top: 30px;
            padding: 12px;
            background: rgba(40, 167, 69, 0.1);
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            font-size: 14px;
            color: #28a745;
        }
        
        /* Footer */
        .footer {
            margin-top: 40px;
            font-size: 12px;
            color: rgba(0, 0, 0, 0.5);
            text-align: center;
        }
        
        /* Responsive Design */
        @media (max-width: 576px) {
            .container {
                padding: 30px 25px;
            }
            
            .logo-text {
                font-size: 24px;
            }
            
            .btn {
                padding: 14px 20px;
            }
        }
    </style>
</head>
<body>
    <!-- Background elements -->
    <div class="bg-circle circle-1"></div>
    <div class="bg-circle circle-2"></div>
    
    <div class="container">
        <div class="logo">
            <div class="logo-icon">
                <i class="fa-solid fa-building-columns"></i>
            </div>
            <div class="logo-text">SecureNet Banking</div>
        </div>
        
        <h1 class="welcome-text">Welcome to SecureNet Banking</h1>
        <p class="subtitle">Secure, convenient banking for everyone</p>
        
        <div class="btn-container">
            <a href="register.jsp" class="btn btn-primary">
                <i class="fa-solid fa-user-plus"></i>
                <span>Register (New User)</span>
            </a>
            
            <a href="login.jsp" class="btn btn-secondary">
                <i class="fa-solid fa-right-to-bracket"></i>
                <span>User Login</span>
            </a>
            
            <a href="adminLogin.jsp" class="btn btn-admin">
                <i class="fa-solid fa-user-shield"></i>
                <span>Admin Login</span>
            </a>
        </div>
        
        <div class="security-badge">
            <i class="fa-solid fa-shield-check"></i>
            <span>256-bit SSL Secured Connection</span>
        </div>
        
        <div class="footer">
            &copy; 2023 SecureNet Banking. All rights reserved.
        </div>
    </div>
</body>
</html>