<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%
    // Get account number from session
    String accountNumber = (String) session.getAttribute("account_number");
    if (accountNumber == null) {
        response.sendRedirect("login.jsp");
        return;
    }
%>
<!DOCTYPE html>
<html>
<head>
    <title>Create Recurring Deposit</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
            height: 100vh;
            width: 100vw;
            background: linear-gradient(135deg, #74ebd5, #ACB6E5);
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .container {
            position: relative;
            background: rgba(255, 255, 255, 0.95);
            border-radius: 20px;
            box-shadow: 0 15px 30px rgba(0,0,0,0.2);
            width: 500px;
            padding: 40px 50px;
            text-align: center;
        }

        h2 {
            margin-bottom: 25px;
            color: #333;
            font-size: 28px;
        }

        form {
            display: flex;
            flex-direction: column;
            align-items: flex-start;
        }

        label {
            font-weight: bold;
            margin-bottom: 5px;
        }

        input[type="text"], input[type="number"], input[type="date"] {
            width: 100%;
            padding: 8px;
            margin-bottom: 15px;
            border-radius: 8px;
            border: 1px solid #ccc;
            box-sizing: border-box;
        }

        input[type="text"][readonly] {
            background-color: #e9ecef;
            cursor: not-allowed;
        }

        input[type="submit"] {
            width: 100%;
            padding: 10px;
            border-radius: 10px;
            border: none;
            background: #74ebd5;
            color: #fff;
            font-weight: bold;
            cursor: pointer;
            transition: background 0.3s, transform 0.3s;
        }

        input[type="submit"]:hover {
            background: #67d3c0;
            transform: scale(1.05);
        }

        .back-link {
            display: inline-block;
            margin-top: 20px;
            text-decoration: none;
            color: #fff;
            font-weight: bold;
            padding: 10px 20px;
            border-radius: 10px;
            background: #74ebd5;
            transition: background 0.3s, transform 0.3s;
        }

        .back-link:hover {
            background: #67d3c0;
            transform: scale(1.05);
        }
    </style>
</head>
<body>
<div class="container">
    <h2>Create Recurring Deposit</h2>
    <form action="RecurringDepositServlet" method="post">
        <label>Account Number:</label>
        <input type="text" name="account_number" value="<%= accountNumber %>" readonly>

        <label>Monthly Amount:</label>
        <input type="number" step="0.01" name="monthly_amount" required>

        <label>Interest Rate (%):</label>
        <input type="number" step="0.01" name="interest_rate" required>

        <label>Start Date:</label>
        <input type="date" name="start_date" required>

        <label>Duration (Months):</label>
        <input type="number" name="duration_months" required>

        <input type="submit" value="Create RD">
    </form>
    <a href="dashboard.jsp" class="back-link">Back to Dashboard</a>
</div>
</body>
</html>
