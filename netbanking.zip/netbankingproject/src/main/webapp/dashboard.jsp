<%@ page language="java" contentType="text/html; charset=UTF-8" %>
<%
    String accountNumber = (String) session.getAttribute("account_number");
    if(accountNumber == null){
        response.sendRedirect("login.jsp");
        return;
    }
%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - SecureNet Banking</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary: #1a4f72;
            --secondary: #3a7dbd;
            --accent: #28a745;
            --light: #f8f9fa;
            --dark: #212529;
            --success: #28a745;
            --danger: #dc3545;
            --warning: #ffc107;
            --info: #17a2b8;
            --gradient-start: #1a4f72;
            --gradient-end: #2c7da0;
            --card-bg: rgba(255, 255, 255, 0.95);
            --shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
            background: linear-gradient(135deg, var(--gradient-start), var(--gradient-end));
            color: var(--dark);
            min-height: 100vh;
            padding: 20px;
            position: relative;
            overflow-x: hidden;
        }
        
        /* Header styles */
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 30px;
            background: var(--card-bg);
            border-radius: 15px;
            box-shadow: var(--shadow);
            margin-bottom: 30px;
        }
        
        .logo {
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .logo-icon {
            font-size: 28px;
            color: var(--primary);
        }
        
        .logo-text {
            font-size: 22px;
            font-weight: 700;
            color: var(--primary);
        }
        
        .user-info {
            display: flex;
            align-items: center;
            gap: 15px;
        }
        
        .account-number {
            background: rgba(26, 79, 114, 0.1);
            padding: 8px 15px;
            border-radius: 20px;
            font-weight: 600;
            color: var(--primary);
        }
        
        /* Main container */
        .dashboard-container {
            max-width: 1200px;
            margin: 0 auto;
            background: var(--card-bg);
            padding: 40px;
            border-radius: 20px;
            box-shadow: var(--shadow);
        }
        
        .welcome-section {
            text-align: center;
            margin-bottom: 40px;
        }
        
        .welcome-title {
            color: var(--primary);
            font-size: 28px;
            margin-bottom: 10px;
        }
        
        .welcome-subtitle {
            color: #666;
            font-size: 16px;
            max-width: 600px;
            margin: 0 auto;
        }
        
        /* Menu grid */
        .menu {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 25px;
            margin-bottom: 40px;
        }
        
        .menu-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 25px 20px;
            background: #fff;
            border-radius: 15px;
            text-decoration: none;
            color: var(--dark);
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }
        
        .menu-item::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 5px;
            height: 100%;
            background: var(--primary);
            transition: width 0.3s ease;
        }
        
        .menu-item:hover {
            transform: translateY(-5px);
            box-shadow: 0 12px 25px rgba(0,0,0,0.15);
        }
        
        .menu-item:hover::before {
            width: 100%;
            opacity: 0.1;
        }
        
        .menu-icon {
            font-size: 32px;
            margin-bottom: 15px;
            color: var(--primary);
            position: relative;
            z-index: 2;
        }
        
        .menu-text {
            font-weight: 600;
            font-size: 16px;
            position: relative;
            z-index: 2;
        }
        
        /* Color variations for different menu items */
        .menu-item.transfer { --primary: #3a7dbd; }
        .menu-item.transactions { --primary: #28a745; }
        .menu-item.balance { --primary: #17a2b8; }
        .menu-item.fd { --primary: #ffc107; }
        .menu-item.rd { --primary: #fd7e14; }
        .menu-item.view-fd { --primary: #6f42c1; }
        .menu-item.view-rd { --primary: #e83e8c; }
        .menu-item.bill { --primary: #dc3545; }
        
        /* Logout button */
        .logout-section {
            text-align: center;
            margin-top: 30px;
            padding-top: 30px;
            border-top: 1px solid rgba(0,0,0,0.1);
        }
        
        .logout-btn {
            display: inline-flex;
            align-items: center;
            gap: 10px;
            padding: 12px 30px;
            background: var(--danger);
            color: white;
            text-decoration: none;
            border-radius: 8px;
            font-weight: 600;
            transition: all 0.3s ease;
            box-shadow: 0 4px 12px rgba(220, 53, 69, 0.25);
        }
        
        .logout-btn:hover {
            background: #bd2130;
            transform: translateY(-2px);
            box-shadow: 0 6px 15px rgba(220, 53, 69, 0.35);
        }
        
        /* Footer */
        .footer {
            margin-top: 50px;
            text-align: center;
            color: rgba(255, 255, 255, 0.7);
            font-size: 14px;
        }
        
        /* Responsive Design */
        @media (max-width: 768px) {
            .header {
                flex-direction: column;
                gap: 15px;
                text-align: center;
            }
            
            .menu {
                grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            }
            
            .dashboard-container {
                padding: 25px;
            }
        }
        
        @media (max-width: 576px) {
            .menu {
                grid-template-columns: 1fr;
            }
            
            .welcome-title {
                font-size: 24px;
            }
        }
    </style>
</head>
<body>
    <!-- Header -->
    <div class="header">
        <div class="logo">
            <i class="fas fa-building-columns logo-icon"></i>
            <div class="logo-text">SecureNet Banking</div>
        </div>
        <div class="user-info">
            <div class="account-number">
                <i class="fas fa-user-circle"></i>
                Account: <%= accountNumber %>
            </div>
        </div>
    </div>
    
    <!-- Dashboard Content -->
    <div class="dashboard-container">
        <div class="welcome-section">
            <h1 class="welcome-title">Welcome to Your Dashboard</h1>
            <p class="welcome-subtitle">Manage your finances, make transactions, and view your account details all in one place.</p>
        </div>
        
        <div class="menu">
            <a href="transfer.jsp" class="menu-item transfer">
                <i class="fas fa-exchange-alt menu-icon"></i>
                <span class="menu-text">Fund Transfer</span>
            </a>
            
            <a href="transactions.jsp" class="menu-item transactions">
                <i class="fas fa-history menu-icon"></i>
                <span class="menu-text">View Transactions</span>
            </a>
            
            <a href="BalanceServlet" class="menu-item balance">
                <i class="fas fa-wallet menu-icon"></i>
                <span class="menu-text">Check Balance</span>
            </a>
            
            <a href="fixedDeposit.jsp" class="menu-item fd">
                <i class="fas fa-chart-line menu-icon"></i>
                <span class="menu-text">Fixed Deposit</span>
            </a>
            
            <a href="recurringDeposit.jsp" class="menu-item rd">
                <i class="fas fa-calendar-alt menu-icon"></i>
                <span class="menu-text">Recurring Deposit</span>
            </a>
            
            <a href="ViewFDServlet" class="menu-item view-fd">
                <i class="fas fa-file-invoice-dollar menu-icon"></i>
                <span class="menu-text">View Fixed Deposits</span>
            </a>
            
            <a href="ViewRDServlet" class="menu-item view-rd">
                <i class="fas fa-list-alt menu-icon"></i>
                <span class="menu-text">View Recurring Deposits</span>
            </a>
            
            <a href="billPayments.jsp" class="menu-item bill">
                <i class="fas fa-receipt menu-icon"></i>
                <span class="menu-text">Bill Payments</span>
            </a>
        </div>
        
        <div class="logout-section">
            <a href="logout.jsp" class="logout-btn">
                <i class="fas fa-sign-out-alt"></i>
                Logout
            </a>
        </div>
    </div>
    
    <div class="footer">
        &copy; 2023 SecureNet Banking. All rights reserved. | <i class="fas fa-shield-alt"></i> Secure & Encrypted
    </div>
</body>
</html>