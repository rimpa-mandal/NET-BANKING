<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <title>Login - NetBanking</title>
    <style>
        /* Body styling with unique gradient background */
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            background: linear-gradient(135deg, #74ebd5, #ACB6E5);
        }

        /* Login container styling */
        .form-container {
            background: rgba(255, 255, 255, 0.95);
            padding: 40px 50px;
            border-radius: 20px;
            box-shadow: 0 15px 30px rgba(0,0,0,0.2);
            width: 350px;
            text-align: center;
            transition: transform 0.3s;
        }

        .form-container:hover {
            transform: translateY(-5px);
        }

        /* Header styling */
        .form-container h2 {
            margin-bottom: 25px;
            color: #333;
            font-size: 28px;
        }

        /* Input styling */
        .form-container input[type="text"],
        .form-container input[type="password"] {
            width: 100%;
            padding: 12px 15px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 10px;
            font-size: 16px;
            outline: none;
            transition: all 0.3s ease;
        }

        .form-container input[type="text"]:focus,
        .form-container input[type="password"]:focus {
            border-color: #74ebd5;
            box-shadow: 0 0 5px rgba(116,235,213,0.5);
        }

        /* Submit button styling */
        .form-container input[type="submit"] {
            width: 100%;
            padding: 12px 15px;
            margin-top: 15px;
            border: none;
            border-radius: 10px;
            background: #74ebd5;
            color: #fff;
            font-size: 18px;
            cursor: pointer;
            transition: background 0.3s ease, transform 0.3s ease;
        }

        .form-container input[type="submit"]:hover {
            background: #67d3c0;
            transform: scale(1.05);
        }

        /* Link styling */
        .form-container p {
            margin-top: 15px;
            font-size: 14px;
            color: #555;
        }

        .form-container a {
            color: #74ebd5;
            text-decoration: none;
            font-weight: bold;
        }

        .form-container a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="form-container">
        <h2>Login</h2>
        <form action="LoginServlet1" method="post">
            <input type="text" name="account_number" placeholder="Account Number" required />
            <input type="password" name="password" placeholder="Password" required />
            <input type="submit" value="Login" />
        </form>
        <p>Don’t have an account? <a href="register.jsp">Register here</a></p>
    </div>
</body>
</html>
