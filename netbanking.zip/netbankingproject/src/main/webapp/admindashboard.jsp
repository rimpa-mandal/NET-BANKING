<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%
    String accountNumber = (String) session.getAttribute("account_number");
    if(accountNumber == null){
        response.sendRedirect("adminLogin.jsp");
        return;
    }
%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard - NetBanking</title>
    <style>
        /* --- Internal CSS starts here --- */
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #e0f7e0, #c6f0c6);
            margin: 0;
            padding: 0;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        header {
            position: absolute;
            top: 0;
            width: 100%;
            background: linear-gradient(to right, #4facfe, #00f2fe);
            color: #fff;
            padding: 25px 0;
            text-align: center;
            font-size: 28px;
            font-weight: bold;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }

        .container {
            background-color: #d4edda;
            padding: 40px 30px;
            text-align: center;
            width: 380px;
            border-radius: 15px;
            box-shadow: 0 10px 20px rgba(0,0,0,0.15);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .container:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 25px rgba(0,0,0,0.2);
        }

        .container h2 {
            margin-bottom: 15px;
            color: #155724;
            font-size: 24px;
        }

        .container p {
            margin-bottom: 25px;
            font-size: 16px;
            color: #0b2e13;
        }

        .container a {
            display: block;
            margin: 10px 0;
            padding: 14px 0;
            font-size: 16px;
            font-weight: 600;
            background: #28a745;
            color: white;
            text-decoration: none;
            border-radius: 8px;
            transition: 0.3s;
            box-shadow: 0 3px 6px rgba(0,0,0,0.1);
        }

        .container a:hover {
            background: #218838;
            transform: translateY(-2px);
            box-shadow: 0 5px 10px rgba(0,0,0,0.15);
        }

        a.logout {
            background: #dc3545;
            font-weight: bold;
        }

        a.logout:hover {
            background: #c82333;
        }
        /* --- Internal CSS ends here --- */
    </style>
</head>
<body>

    <div class="container">
        <h2>Welcome, Admin!</h2>
        <p>Account Number: <strong><%= accountNumber %></strong></p>
        
        <a href="AdminViewUsersServlet1">View Users</a>
        <a href="adminDeleteUser.jsp">Delete User</a>
        <a href="adminAdjustBalance.jsp">Adjust Balance</a>
        <a href="AdminViewTransactionsServlet1">View Transactions</a>
        
        <a href="adminLogout.jsp" class="logout">Logout</a>
    </div>
</body>
</html>
