package netbanking;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

public class AdminAdjustBalanceServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        String accNo = request.getParameter("account_number");
        String action = request.getParameter("action"); // credit or debit
        double amount = Double.parseDouble(request.getParameter("amount"));

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/netbankingdb?useSSL=false&allowPublicKeyRetrieval=true",
                "root", "MySQL@1234"); // change your password

            // First check balance
            PreparedStatement psCheck = con.prepareStatement("SELECT balance FROM users WHERE account_number=?");
            psCheck.setString(1, accNo);
            ResultSet rs = psCheck.executeQuery();

            if (rs.next()) {
                double currentBalance = rs.getDouble("balance");
                double newBalance = currentBalance;

                if ("credit".equals(action)) {
                    newBalance = currentBalance + amount;
                } else if ("debit".equals(action)) {
                    if (currentBalance >= amount) {
                        newBalance = currentBalance - amount;
                    } else {
                        out.println("<h2>Insufficient balance for debit operation!</h2>");
                        out.println("<a href='adminAdjustBalance.jsp'>Try Again</a>");
                        return;
                    }
                }

                PreparedStatement psUpdate = con.prepareStatement(
                        "UPDATE users SET balance=? WHERE account_number=?");
                psUpdate.setDouble(1, newBalance);
                psUpdate.setString(2, accNo);
                psUpdate.executeUpdate();

                out.println("<h2>Balance Updated Successfully!</h2>");
                out.println("<p>Account No: " + accNo + "</p>");
                out.println("<p>New Balance: " + newBalance + "</p>");
                out.println("<a href='adminMenu.jsp'>Back to Admin Menu</a>");
            } else {
                out.println("<h2>No user found with this Account Number!</h2>");
            }

            con.close();

        } catch (Exception e) {
            out.println("Error: " + e.getMessage());
        }
    }
}
