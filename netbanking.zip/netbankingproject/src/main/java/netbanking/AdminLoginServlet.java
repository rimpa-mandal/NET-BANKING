package netbanking;

import java.io.IOException;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class AdminLoginServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String accountNumber = request.getParameter("account_number");
        String password = request.getParameter("password");

        Connection conn = null;
        PreparedStatement pst = null;
        ResultSet rs = null;

        try {
            // Load MySQL driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Connect to your database (change password if needed)
            conn = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/netbankingdb", "root", "MySQL@1234");

            // Query to check admin credentials
            String sql = "SELECT * FROM admin WHERE account_number=? AND password=?";
            pst = conn.prepareStatement(sql);
            pst.setString(1, accountNumber);
            pst.setString(2, password);

            rs = pst.executeQuery();

            if (rs.next()) {
                // Login successful, set session
                HttpSession session = request.getSession();
                session.setAttribute("account_number", accountNumber);
                response.sendRedirect("admindashboard.jsp");
            } else {
                // Invalid credentials
                request.setAttribute("error", "Invalid account number or password");
                RequestDispatcher rd = request.getRequestDispatcher("adminLogin.jsp");
                rd.forward(request, response);
            }

        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "Database connection error");
            RequestDispatcher rd = request.getRequestDispatcher("adminLogin.jsp");
            rd.forward(request, response);
        } finally {
            try { if(rs != null) rs.close(); } catch(Exception e) {}
            try { if(pst != null) pst.close(); } catch(Exception e) {}
            try { if(conn != null) conn.close(); } catch(Exception e) {}
        }
    }
}
