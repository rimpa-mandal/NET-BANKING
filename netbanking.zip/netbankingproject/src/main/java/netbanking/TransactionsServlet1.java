package netbanking;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

public class TransactionsServlet1 extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("account_number") == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        String accNo = (String) session.getAttribute("account_number");

        out.println("<html><head><title>Transactions</title>");
        out.println("<link rel='stylesheet' href='style.css'>");
        out.println("</head><body>");
        out.println("<h2>Transaction History for Account: " + accNo + "</h2>");
        out.println("<table border='1' cellpadding='10'>");
        out.println("<tr><th>ID</th><th>From Account</th><th>To Account</th><th>Amount</th><th>Date</th></tr>");

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/netbankingdb?useSSL=false&allowPublicKeyRetrieval=true",
                "root", "MySQL@1234"); // <-- replace with your MySQL password

            PreparedStatement ps = con.prepareStatement(
                "SELECT * FROM transactions WHERE from_account=? OR to_account=? ORDER BY date DESC");
            ps.setString(1, accNo);
            ps.setString(2, accNo);

            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                out.println("<tr>");
                out.println("<td>" + rs.getInt("id") + "</td>");
                out.println("<td>" + rs.getString("from_account") + "</td>");
                out.println("<td>" + rs.getString("to_account") + "</td>");
                out.println("<td>" + rs.getDouble("amount") + "</td>");
                out.println("<td>" + rs.getTimestamp("date") + "</td>");
                out.println("</tr>");
            }

            out.println("</table>");
            out.println("<br><a href='dashboard.jsp'>Back to Dashboard</a>");
            con.close();
        } catch (Exception e) {
            e.printStackTrace(out);
        }

        out.println("</body></html>");
    }
}
