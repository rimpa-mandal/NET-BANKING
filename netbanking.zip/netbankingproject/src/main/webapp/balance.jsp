<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%
    Double balance = (Double) request.getAttribute("balance");
%>
<!DOCTYPE html>
<html>
<head>
    <title>Balance Check</title>
</head>
<body>
    <h2>Your Current Balance:</h2>
    <h3 style="color:green;">₹ <%= balance %></h3>
    <p><a href="dashboard.jsp">Back to Dashboard</a></p>
</body>
</html>
