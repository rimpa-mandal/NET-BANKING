package netbanking;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

public class BillPaymentServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String fromAccount = request.getParameter("from_account");
        String billType = request.getParameter("bill_type");
        String amountStr = request.getParameter("amount");

        double amount = Double.parseDouble(amountStr);

        Connection conn = null;
        PreparedStatement ps = null;

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/netbankingdb","root","MySQL@1234"
            ); 

            // Check balance
            ps = conn.prepareStatement("SELECT balance FROM users WHERE account_number=?");
            ps.setString(1, fromAccount);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                double balance = rs.getDouble("balance");
                if (balance < amount) {
                    showMessage(out, "Insufficient balance!");
                    return;
                }
            } else {
                showMessage(out, "Account not found!");
                return;
            }

            // Deduct balance
            ps = conn.prepareStatement("UPDATE users SET balance=balance-? WHERE account_number=?");
            ps.setDouble(1, amount);
            ps.setString(2, fromAccount);
            ps.executeUpdate();

            // Add transaction
            ps = conn.prepareStatement(
                "INSERT INTO transactions (from_account, to_account, amount, type) VALUES (?, ?, ?, ?)"
            );
            ps.setString(1, fromAccount);
            ps.setString(2, billType); // Dummy biller
            ps.setDouble(3, amount);
            ps.setString(4, "bill_payment");
            ps.executeUpdate();

            showMessage(out, "Bill Paid Successfully!");

        } catch (Exception e) {
            showMessage(out, "Error: " + e.getMessage());
        } finally {
            try { if (ps != null) ps.close(); } catch(Exception e){}
            try { if (conn != null) conn.close(); } catch(Exception e){}
        }
    }

    private void showMessage(PrintWriter out, String message) {
        out.println("<!DOCTYPE html>");
        out.println("<html>");
        out.println("<head>");
        out.println("<title>Bill Payment</title>");
        out.println("<style>");
        out.println("body {margin:0;height:100vh;font-family:Arial,sans-serif;" +
                    "background:linear-gradient(135deg,#6a11cb,#2575fc);display:flex;" +
                    "justify-content:center;align-items:center;}");
        out.println(".container {width:400px;padding:30px;background-color:#ffffff;" +
                    "border-radius:12px;box-shadow:0 8px 20px rgba(0,0,0,0.3);text-align:center;}");
        out.println("h3 {color:#333;}");
        out.println("a {display:block;margin-top:20px;color:#2575fc;text-decoration:none;}");
        out.println("a:hover {text-decoration:underline;}");
        out.println("</style>");
        out.println("</head>");
        out.println("<body>");
        out.println("<div class='container'>");
        out.println("<h3>" + message + "</h3>");
        out.println("<a href='dashboard.jsp'>Back to Dashboard</a>");
        out.println("</div>");
        out.println("</body>");
        out.println("</html>");
    }
}
