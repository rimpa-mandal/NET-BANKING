package netbanking;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

public class CancelRDServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        String rdIdStr = request.getParameter("rd_id");

        if(rdIdStr == null || rdIdStr.isEmpty()) {
            out.println("<p style='color:red;'>Invalid Recurring Deposit ID!</p>");
            out.println("<a href='ViewRDServlet'>Back to RD List</a>");
            return;
        }

        try {
            int rdId = Integer.parseInt(rdIdStr);

            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/netbankingdb?useSSL=false&allowPublicKeyRetrieval=true",
                "root", "MySQL@1234");

            // Delete RD from database
            PreparedStatement ps = con.prepareStatement("DELETE FROM recurring_deposits WHERE id=?");
            ps.setInt(1, rdId);
            int rows = ps.executeUpdate();

            if(rows > 0) {
                out.println("<!DOCTYPE html>");
                out.println("<html><head><title>RD Cancelled</title>");
                out.println("<style>");
                out.println("body{font-family:Arial,sans-serif;background:linear-gradient(to right,#74ebd5,#ACB6E5);text-align:center;padding:50px;}");
                out.println("a{display:inline-block;margin-top:20px;text-decoration:none;color:#fff;background:#333;padding:10px 15px;border-radius:5px;}");
                out.println("a:hover{background:#555;}");
                out.println("</style></head><body>");
                out.println("<h2>Recurring Deposit Cancelled Successfully!</h2>");
                out.println("<a href='ViewRDServlet'>Back to RD List</a>");
                out.println("</body></html>");
            } else {
                out.println("<p style='color:red;'>RD not found or already cancelled!</p>");
                out.println("<a href='ViewRDServlet'>Back to RD List</a>");
            }

            con.close();
        } catch(Exception e) {
            out.println("<p style='color:red;'>Error: " + e.getMessage() + "</p>");
            out.println("<a href='ViewRDServlet'>Back to RD List</a>");
        }
    }
}
