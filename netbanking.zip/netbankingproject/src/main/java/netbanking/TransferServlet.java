package netbanking;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

public class TransferServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("account_number") == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        String fromAcc = (String) session.getAttribute("account_number");
        String toAcc = request.getParameter("to_account");
        double amount = Double.parseDouble(request.getParameter("amount"));

        out.println("<!DOCTYPE html>");
        out.println("<html><head><title>Transfer Status</title>");
        // Inline CSS for container and messages
        out.println("<style>");
        out.println("body { display:flex; justify-content:center; align-items:center; height:100vh; font-family:Arial, sans-serif; background: linear-gradient(135deg, #74ebd5, #ACB6E5); margin:0; }");
        out.println(".container { background: rgba(255,255,255,0.95); padding: 40px 50px; border-radius: 20px; box-shadow: 0 15px 30px rgba(0,0,0,0.2); text-align:center; width: 400px; }");
        out.println(".success { color: green; font-size: 22px; margin-bottom: 20px; }");
        out.println(".error { color: red; font-size: 22px; margin-bottom: 20px; }");
        out.println(".btn { display:inline-block; padding: 10px 20px; border-radius:10px; text-decoration:none; background:#74ebd5; color:#fff; font-weight:bold; transition: background 0.3s, transform 0.3s; }");
        out.println(".btn:hover { background:#67d3c0; transform: scale(1.05); }");
        out.println("</style>");
        out.println("</head><body>");
        out.println("<div class='container'>");

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/netbankingdb?useSSL=false&allowPublicKeyRetrieval=true",
                "root", "MySQL@1234"); // <-- change to your password

            // Check sender balance
            PreparedStatement ps1 = con.prepareStatement(
                "SELECT balance FROM users WHERE account_number=?");
            ps1.setString(1, fromAcc);
            ResultSet rs1 = ps1.executeQuery();

            if (rs1.next()) {
                double balance = rs1.getDouble("balance");

                if (balance < amount) {
                    out.println("<div class='error'> Insufficient Balance!</div>");
                    out.println("<a class='btn' href='transfer.jsp'>Try Again</a>");
                    return;
                }

                // Deduct from sender
                PreparedStatement ps2 = con.prepareStatement(
                    "UPDATE users SET balance=balance-? WHERE account_number=?");
                ps2.setDouble(1, amount);
                ps2.setString(2, fromAcc);
                ps2.executeUpdate();

                // Add to receiver
                PreparedStatement ps3 = con.prepareStatement(
                    "UPDATE users SET balance=balance+? WHERE account_number=?");
                ps3.setDouble(1, amount);
                ps3.setString(2, toAcc);
                int rowsUpdated = ps3.executeUpdate();

                if (rowsUpdated == 0) {
                    // rollback sender deduction if receiver not found
                    PreparedStatement rollback = con.prepareStatement(
                        "UPDATE users SET balance=balance+? WHERE account_number=?");
                    rollback.setDouble(1, amount);
                    rollback.setString(2, fromAcc);
                    rollback.executeUpdate();

                    out.println("<div class='error'> Receiver account not found!</div>");
                    out.println("<a class='btn' href='transfer.jsp'>Try Again</a>");
                    return;
                }

                // Insert transaction record
                PreparedStatement ps4 = con.prepareStatement(
                    "INSERT INTO transactions(from_account,to_account,amount) VALUES (?,?,?)");
                ps4.setString(1, fromAcc);
                ps4.setString(2, toAcc);
                ps4.setDouble(3, amount);
                ps4.executeUpdate();

                out.println("<div class='success'> Transfer Successful!</div>");
                out.println("<a class='btn' href='dashboard.jsp'>Back to Dashboard</a>");
            }

            con.close();
        } catch (Exception e) {
            out.println("<div class='error'>Error occurred: " + e.getMessage() + "</div>");
            out.println("<a class='btn' href='transfer.jsp'>Try Again</a>");
        }

        out.println("</div></body></html>");
    }
}
